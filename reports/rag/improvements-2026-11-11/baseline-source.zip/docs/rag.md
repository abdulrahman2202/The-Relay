# Research-paper ingestion and retrieval

This module validates and indexes exactly these supplied files:

| File | Paper | arXiv version | Physical PDF pages |
| --- | --- | --- | --- |
| `papers/attention_is_all_you_need.pdf` | Attention Is All You Need | 1706.03762v7 | 15 |
| `papers/moshi.pdf` | Moshi: a speech-text foundation model for real-time dialogue | 2410.00037v1 | 66 |
| `papers/dynamic_chunking.pdf` | Dynamic Chunking for End-to-End Hierarchical Sequence Modeling | 2507.07955v2 | 39 |

The manifest in `src/retrieval/catalog.py` pins each file's SHA-256, title, arXiv ID,
and version. Ingestion checks filenames, checksums, and the first-page arXiv stamp
before writing an index. Missing, changed, extra, or duplicated PDF files are errors.
The checksums identify the supplied bytes; another download of the same arXiv
version can have different bytes and is intentionally rejected. Updating the corpus
requires an explicit manifest review.

## Setup

The implementation was developed with Python 3.12.2. Use the existing virtual
environment, or create one with Python 3.12. Run commands from the repository root.

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -c requirements.txt -e ".[dev]"
```

`pyproject.toml` pins the module's runtime dependencies, Pytest, and Ruff. The
existing `requirements.txt` supplies constraints for transitive dependencies; it
has not been rewritten. The package installs only the `retrieval` namespace from
`src`. On Linux/macOS, replace `.venv\Scripts\python.exe` with `.venv/bin/python`.

Provision model files once if the following revision is not already cached. This
optional preparation step downloads model assets; it never uploads paper text.
The ingestion and search commands themselves operate with `local_files_only=True`
and fail clearly when the required snapshot is absent.

```powershell
.venv\Scripts\python.exe -c "from huggingface_hub import snapshot_download; snapshot_download(repo_id='sentence-transformers/all-MiniLM-L6-v2', revision='c9745ed1d9f207416be6d2e6f8de32d1f16199bf', allow_patterns=['*.json', '*.safetensors', 'vocab.txt'])"
```

The default Hugging Face hub cache is used. To use another hub cache, pass its path
as `cache_dir` to `snapshot_download` and `--model-cache` to ingestion/search. Supply
the hub cache directory, not an individual snapshot directory. A provisioned cache
can also be copied from another machine for offline setup.

## Commands

Inspect extraction without loading an embedding model. The command prints a JSON
summary; the Python extraction API exposes the actual page text and section spans.
Logs go to stderr. `--output` also writes the JSON result as UTF-8.

```powershell
.venv\Scripts\python.exe -m retrieval extract --output reports/rag/extraction.json
```

Ingest and query the default 300-token / top-3 configuration:

```powershell
.venv\Scripts\python.exe -m retrieval ingest --preset 300 --output reports/rag/ingestion-300.json
.venv\Scripts\python.exe -m retrieval search "Why are attention scores scaled by the square root of the key dimension?" --preset 300
.venv\Scripts\python.exe -m retrieval search "What is Moshi's theoretical latency?" --preset 300 --arxiv-id 2410.00037 --top-k 3
```

Prepare the other evaluation configurations in the same local database:

```powershell
.venv\Scripts\python.exe -m retrieval ingest --preset 600 --output reports/rag/ingestion-600.json
.venv\Scripts\python.exe -m retrieval ingest --preset 900 --output reports/rag/ingestion-900.json
.venv\Scripts\python.exe -m retrieval search "How does H-Net learn dynamic chunk boundaries?" --preset 600
.venv\Scripts\python.exe -m retrieval search "How does H-Net learn dynamic chunk boundaries?" --preset 900
```

| Preset | Maximum chunk tokens | Overlap tokens | Default retrieved chunks |
| --- | ---: | ---: | ---: |
| 300 | 300 | 50 | 3 |
| 600 | 600 | 50 | 4 |
| 900 | 900 | 50 | 5 |

Overlap stays at 50 across the presets. These are candidate configurations, with
no quality ranking implied. `--chunk-size`, `--overlap`, and `--top-k` override
preset values. Overlap must be nonnegative and less than chunk size; chunk size,
top-k, and `--batch-size` must be positive integers. Changing chunk size/overlap
requires ingestion of that configuration before querying it. Top-k is query-only
and reuses the same index. Search caps top-k at the available matching chunk count.

```powershell
.venv\Scripts\python.exe -m retrieval ingest --chunk-size 600 --overlap 80 --batch-size 8
.venv\Scripts\python.exe -m retrieval search "Explain Inner Monologue" --chunk-size 600 --overlap 80 --top-k 4
```

`--papers-dir` defaults to `papers`; `--db-dir` defaults to `data/chroma`. Chroma data
is local and git-ignored. Different chunk, model, or recorded runtime settings have
separate fingerprinted collections. Ingestion retries reuse stored deterministic
IDs and embed only missing chunks. There is no automatic deletion of collections;
use a separate `--db-dir` for a fresh experiment.

Use `python -m retrieval --verbose ...` for a traceback and debug logs when diagnosing
an error. Expected validation, extraction, embedding, and storage errors exit with
status 1; invalid command syntax exits with status 2. Neither logs nor embedding
errors intentionally print complete paper text.

## Architecture and reusable interfaces

```text
Fixed PDF manifest -> validation -> page/section extraction
    -> WordPiece chunks + source spans -> local MiniLM windows
    -> normalized pooled embeddings -> persistent Chroma collection
Query -> same local embedding procedure -> cosine search -> cited passages
```

| Module | Responsibility |
| --- | --- |
| `catalog.py` | Exact corpus identities, checksums, and version validation |
| `extraction.py` | PyMuPDF text, physical page numbering, section spans, extraction issues |
| `chunking.py` | Configurable token windows and character-to-source mapping |
| `embeddings.py` | Pinned SentenceTransformer tokenizer and CPU inference |
| `index.py` | Local Chroma storage, readiness checks, and semantic search |
| `pipeline.py` | Ingestion/retry orchestration and bounded context construction |
| `models.py`, `config.py`, `errors.py` | Typed records, validated settings, and public error types |
| `cli.py` | JSON command-line interface |

PyMuPDF reads text spans in geometric order. Extraction normalizes Unicode with
NFKC and collapses whitespace within lines. It removes rotated margin text, isolated
bottom page numbers, and exact paper-title headers near the top margin. Section
recognition matches PDF outline titles against lines on the bookmarked physical page
and also recognizes
named or visually emphasized numbered headings. The most recent recognized section
carries to the next page. Unrecognized front matter has `section=None`; no section
is invented from a page number alone.

Blank pages produce logged `empty_page` issues. Repeated normalized page text
produces `duplicate_page` issues containing the original physical page reference.
Blank and duplicate pages do not enter chunking. A corrupt, encrypted, wholly
unreadable PDF or page extraction exception aborts ingestion; there is no silent
partial-corpus indexing. Extraction completes for all papers before any store write.

Chunks use the pinned MiniLM WordPiece tokenizer, excluding special tokens. They
can cross page and section boundaries but never paper boundaries. Source spans map
each piece back to its exact extracted page/section. Final windows can be shorter
than the configured maximum. Token offsets determine overlap; a cut inside a
WordPiece can change the substring's tokenization, so the returned text is recounted
and the window shortened when necessary. Extremely small chunk sizes may be rejected
if a tokenizer boundary cannot be represented within the limit.

Each Chroma record stores the original extracted chunk text, document ID, paper
title, arXiv ID, version, PDF checksum, relative source filename, versioned source
URL, token/character positions, content hash, first/last page, exact page list,
sections, and per-page/section character spans. Lists and nested source spans are
serialized as JSON strings for portable Chroma metadata. `page_number` aliases the
first physical page; `page_numbers_json` is authoritative when pages are noncontiguous.

Within one paper, identical normalized chunks are indexed once, with discarded
locations recorded in the ingestion report. Identical passages across papers are
detected but both are kept to preserve attribution. PDF/page/chunk hashes ignore
whitespace only where documented; no fuzzy or semantic deduplication is performed.

MiniLM's configured sequence limit is 256 tokens, including two BERT special tokens.
All three requested chunk sizes exceed that limit. Each chunk or query is therefore
split into nonoverlapping windows of at most 254 content token IDs. The local
SentenceTransformer processes every window. Window vectors are normalized, averaged
with content-token-count weights, and normalized again into one 384-dimensional
vector. Token IDs enter the model directly, without decoding and re-tokenizing.
The same procedure is used for queries and documents. Long inputs are never silently
truncated to the first 256 tokens.

Chroma uses cosine HNSW search with explicit vectors, `embedding_function=None`, and
anonymized telemetry disabled. It cannot fall back to its default embedding download.
The pipeline uses deterministic IDs and `upsert`; unchanged retries skip embedding
work. A collection is marked incomplete before writes and becomes searchable only
after its stored ID set matches the expected corpus chunks. A failed batch leaves
the collection unavailable for search; rerunning ingestion resumes missing rows.
Unexpected rows cause an error instead of silently mixing corpora. This is a
single-writer module; concurrent ingestion/read consistency is outside this phase.

```python
from pathlib import Path

from retrieval.config import PRESETS
from retrieval.pipeline import RetrievalPipeline, build_context

rag = RetrievalPipeline(
    papers_dir=Path("papers"),
    db_dir=Path("data/chroma"),
    config=PRESETS[600],
)
report = rag.ingest()
hits = rag.search("How does Moshi handle overlapping speech?", arxiv_id="2410.00037")
for hit in hits:
    print(hit.citation, hit.source_url, hit.score)
    print(hit.text)

# Optional input for a future answer-generation layer. This performs no LLM call.
context = build_context(hits, rag.embedder.tokenizer, max_tokens=3000)
```

`SearchHit.to_dict()` provides serializable text, sources, physical pages, sections,
versioned citation, URL with a PDF page fragment, cosine distance, and cosine
similarity (`1 - distance`). Similarity is not a factual-confidence probability.
`build_context` includes complete cited hits in rank order, stops at the first hit
that would exceed its token budget, and counts citation headers and separators.
It returns an empty string if no complete cited hit fits. No entire-paper context is
constructed or sent to an LLM. Budget counts use the supplied tokenizer; a future
generation model with a different tokenizer needs its own final prompt budget check.

## Reproducibility, tests, and evaluation preparation

Document IDs include the exact paper/version and PDF hash. Chunk IDs additionally
include pipeline revision, tokenizer revision, chunk settings, token position, and
text. Collection fingerprints include the manifest, pipeline revision, chunk settings,
embedding strategy/revision, and recorded runtime dependency versions. Absolute file
paths and top-k do not affect IDs. Increment `PIPELINE_VERSION` when changing
extraction, chunking, metadata, or embedding
semantics so earlier collections cannot be reused with changed behavior.
Ingestion preserves fixed paper/chunk order. Embedding inference runs in evaluation
mode on CPU, with seed 0, deterministic
PyTorch algorithms, and one PyTorch thread. These PyTorch settings affect the
hosting process. Chroma HNSW uses one thread. Reports include configuration,
fingerprint, dependencies, per-paper counts/issues, and new/reused/duplicate counts.

```powershell
# Fast offline suite, including actual PDF extraction and real temporary Chroma DBs.
.venv\Scripts\python.exe -m pytest -q

# Full suite, adding cached-model inference and retrieval for all three presets.
.venv\Scripts\python.exe -m pytest -q --run-integration

# Run only the real-model integration tests.
.venv\Scripts\python.exe -m pytest -q --run-integration -m integration

.venv\Scripts\python.exe -m ruff check src/retrieval tests/rag
.venv\Scripts\python.exe -m ruff format --check src/retrieval tests/rag
```

The default suite uses explicitly synthetic embeddings for storage/orchestration
tests, generated PDFs for failures/duplicates, and all supplied PDFs for extraction.
It makes no semantic-quality claim based on those synthetic vectors. Integration
tests require the pinned local model; when requested, missing assets fail the tests
instead of being silently skipped. Tests block Python socket connections, covering
offline operation. Test database files are isolated under Pytest temporary directories.
The pre-existing `tests/test_model.py` and `tests/groqtest.py` are manual scripts that
call Groq at import/execution time. They are unchanged and excluded by the new
`testpaths = ["tests/rag"]` setting.

The integration checks compare short-input embeddings with standard
SentenceTransformers output, verify that long-input suffixes affect embeddings, and
check cited retrieval for one known question per paper across all three presets.
These assertions check paper/page hits, not whether the particular chunk contains
every fact needed to answer the question. The saved 300-token Moshi latency example
returns relevant pages but omits the requested numerical values; see
[`reports/rag/validation.md`](../reports/rag/validation.md).
These are smoke checks, not an evaluation dataset or evidence of configuration
superiority. For a later measured comparison, freeze a larger query set with
annotated relevant passages/pages, use identical PDFs/model/overlap, and record
Recall@k, precision, MRR/nDCG, citation correctness, query latency, index size, and
context-token cost for every preset. Record unanswerable and cross-paper questions
as well. Choose a configuration only after measuring the agreed metrics.

## Known limitations

- Extraction does not perform OCR, reconstruct tables, or interpret figures and
  mathematical notation. Two-column pages, captions, footnotes, ligatures, and
  line-end hyphenation can retain imperfect reading order/text. Rotated body text
  is omitted along with margin stamps. Empty-page detection cannot identify every
  image whose only extractable text is a caption or header.
- Section detection uses bookmarks and layout/text heuristics, not a document-layout
  model. Some section names may be absent or imperfect. Citations always use
  physical PDF pages, which can differ from printed page labels.
- WordPiece windows can split sentences or words. Pooling every local window avoids
  data loss from truncation but cannot model interactions across the full 600/900
  tokens in one transformer pass. It may dilute a small relevant passage inside a
  large chunk. No size or pooling strategy is claimed superior without evaluation.
- Duplicate pages and within-paper duplicate chunks retain their first indexed
  location; alternative occurrences are available in the ingestion report. Small
  textual changes and approximate duplicates remain indexed.
- HNSW is approximate. Fixed ordering/settings and sorted returned ties improve
  repeatability, but identical neighbor membership or bitwise floating-point output
  across dependency, CPU, or operating-system changes is not guaranteed. Changing
  recorded dependencies creates another collection. Index manifests should be
  treated as trusted local data, and ingestion should have one writer at a time.
- Search returns the nearest passages even for out-of-domain questions. There is
  no calibrated relevance threshold, reranker, query expansion, answer generation,
  contradiction resolution, or automated full retrieval benchmark in this module.

The module ends at cited retrieval and bounded context preparation. Application
integration and selection of the best retrieval configuration await review and
measurement.
