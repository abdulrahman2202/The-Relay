"""Page-aware PyMuPDF extraction with conservative section recognition."""

import logging
import re
import unicodedata
from collections import defaultdict
from pathlib import Path
from statistics import median

import pymupdf

from .errors import ExtractionError
from .models import (
    ExtractedPaper,
    ExtractionIssue,
    PageText,
    PaperSpec,
    SectionSpan,
    content_hash,
)

logger = logging.getLogger(__name__)
_SECTION_PREFIX = re.compile(r"^(?:\d+(?:\.\d+)*\.?|[A-Z](?:\.\d+)*)\s+")
_SECTION_NUMBER = re.compile(r"(?:\d+(?:\.\d+)*\.?|[A-Z](?:\.\d+)*)")
_NAMED_HEADINGS = {"abstract", "references", "acknowledgments", "acknowledgements", "appendix"}


def _normalize(text: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", text).replace("\x00", "").split())


def _heading_key(text: str) -> str:
    return _SECTION_PREFIX.sub("", _normalize(text)).casefold().rstrip(".")


def _page_lines(page: pymupdf.Page, title: str) -> list[tuple[str, bool, float]]:
    lines = []
    for block in page.get_text("dict", sort=True)["blocks"]:
        if block["type"] != 0:
            continue
        for line in block["lines"]:
            dx, dy = line.get("dir", (1, 0))
            if abs(dy) > abs(dx):
                # The rotated arXiv margin stamp otherwise interleaves with body text.
                continue
            spans = line["spans"]
            fragments: list[str] = []
            for index, span in enumerate(spans):
                if index and span["bbox"][0] - spans[index - 1]["bbox"][2] > 1:
                    fragments.append(" ")
                fragments.append(span["text"])
            text = _normalize("".join(fragments))
            if not text:
                continue
            y = line["bbox"][1]
            if text.isdigit() and y > page.rect.height * 0.88:
                continue
            if y < page.rect.height * 0.09 and text.casefold() == title.casefold():
                continue
            bold = any(span["flags"] & 16 for span in spans)
            size = max((span["size"] for span in spans), default=0)
            lines.append((text, bold, size))
    return lines


def _assemble_page(
    lines: list[tuple[str, bool, float]],
    known_headings: set[str],
    current_section: str | None,
) -> tuple[str, tuple[SectionSpan, ...], str | None]:
    parts: list[str] = []
    sections: list[SectionSpan] = []
    position = 0
    section_start = 0
    body_size = median(size for _, _, size in lines) if lines else 0
    for text, bold, size in lines:
        key = _heading_key(text)
        numbered_heading = (
            _SECTION_PREFIX.match(text)
            and (bold or size > body_size * 1.12)
            and len(text) < 140
            and not text.endswith((".", ",", ";"))
        )
        is_heading = key in known_headings or key in _NAMED_HEADINGS or numbered_heading
        if is_heading:
            heading_start = position
            section_name = text
            if parts and _SECTION_NUMBER.fullmatch(parts[-1].strip()):
                section_name = f"{parts[-1].strip()} {text}"
                heading_start -= len(parts[-1])
            if section_name != current_section:
                if heading_start > section_start:
                    sections.append(SectionSpan(section_start, heading_start, current_section))
                section_start = heading_start
                current_section = section_name
        parts.append(text + "\n")
        position += len(text) + 1
    if position > section_start:
        sections.append(SectionSpan(section_start, position, current_section))
    return "".join(parts), tuple(sections), current_section


def extract_pdf(paper: PaperSpec, papers_dir: Path) -> ExtractedPaper:
    """Extract all readable pages. Page failures are fatal; blank/duplicate pages are reported.

    Corpus validation is separate so extraction can also be tested with generated PDFs.
    Pages use physical, one-based PDF numbering, including front matter and appendices.
    """
    path = Path(papers_dir) / paper.filename
    pages: list[PageText] = []
    issues: list[ExtractionIssue] = []
    seen: dict[str, int] = {}
    current_section = None
    try:
        with pymupdf.open(path) as document:
            if document.needs_pass:
                raise ExtractionError(f"Encrypted PDF requires a password: {path}")
            headings_by_page: dict[int, set[str]] = defaultdict(set)
            for _, title, heading_page in document.get_toc():
                headings_by_page[heading_page].add(_heading_key(title))
            page_count = document.page_count
            for page_index in range(page_count):
                page_number = page_index + 1
                try:
                    lines = _page_lines(document[page_index], paper.title)
                    text, sections, next_section = _assemble_page(
                        lines, headings_by_page[page_number], current_section
                    )
                except Exception as exc:
                    raise ExtractionError(
                        f"Extraction failed for {paper.filename}, page {page_number}: {exc}"
                    ) from exc
                if not text.strip():
                    issue = ExtractionIssue("empty_page", page_number, "No extractable body text")
                    issues.append(issue)
                    logger.warning("%s page %d: %s", paper.filename, page_number, issue.message)
                    continue
                digest = content_hash(text)
                duplicate_of = seen.get(digest)
                if duplicate_of is not None:
                    issue = ExtractionIssue(
                        "duplicate_page", page_number, "Repeated normalized page text", duplicate_of
                    )
                    issues.append(issue)
                    logger.warning(
                        "%s page %d duplicates page %d", paper.filename, page_number, duplicate_of
                    )
                else:
                    seen[digest] = page_number
                    current_section = next_section
                pages.append(PageText(page_number, text, sections, digest, duplicate_of))
    except ExtractionError:
        raise
    except Exception as exc:
        raise ExtractionError(f"Cannot extract {path}: {exc}") from exc
    if not pages:
        raise ExtractionError(f"No extractable text in {path}; scanned PDFs require OCR")
    logger.info("Extracted %s: %d pages, %d issues", paper.filename, page_count, len(issues))
    return ExtractedPaper(paper, page_count, tuple(pages), tuple(issues))
