"""Immutable settings; query-only settings do not change the index identity."""

from dataclasses import dataclass
from types import MappingProxyType

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
MODEL_REVISION = "c9745ed1d9f207416be6d2e6f8de32d1f16199bf"
PIPELINE_VERSION = "relay-rag-v1"


@dataclass(frozen=True)
class RagConfig:
    chunk_size: int = 300
    overlap: int = 50
    top_k: int = 3
    batch_size: int = 16

    def __post_init__(self) -> None:
        for name in ("chunk_size", "top_k", "batch_size"):
            value = getattr(self, name)
            if type(value) is not int or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if type(self.overlap) is not int or not 0 <= self.overlap < self.chunk_size:
            raise ValueError("overlap must be an integer in [0, chunk_size)")

    @property
    def indexing_settings(self) -> dict[str, int]:
        return {"chunk_size": self.chunk_size, "overlap": self.overlap}


# A constant overlap keeps this variable fixed across the requested comparisons.
PRESETS = MappingProxyType(
    {
        300: RagConfig(chunk_size=300, overlap=50, top_k=3),
        600: RagConfig(chunk_size=600, overlap=50, top_k=4),
        900: RagConfig(chunk_size=900, overlap=50, top_k=5),
    }
)
