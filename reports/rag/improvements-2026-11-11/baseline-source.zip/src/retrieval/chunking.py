"""Token windows that retain the exact extracted text and its source spans."""

from typing import Any

from .config import MODEL_NAME, MODEL_REVISION, PIPELINE_VERSION, RagConfig
from .models import Chunk, ExtractedPaper, SourceSpan, stable_hash


def chunk_paper(document: ExtractedPaper, tokenizer: Any, config: RagConfig) -> list[Chunk]:
    """Chunk one paper using the embedding model's tokenizer, without special tokens.

    Windows may cross pages or sections, but never papers. Duplicate pages are omitted
    with their original page numbers retained in the extraction report. Source spans
    retain all page/section transitions within a window.
    """
    parts: list[str] = []
    spans: list[SourceSpan] = []
    position = 0
    for page in document.pages:
        if page.duplicate_of is not None:
            continue
        for section in page.sections:
            spans.append(
                SourceSpan(
                    page.page_number,
                    section.section,
                    position + section.start_char,
                    position + section.end_char,
                )
            )
        parts.append(page.text + "\n")
        position += len(page.text) + 1
    text = "".join(parts)
    encoded = tokenizer(
        text,
        add_special_tokens=False,
        return_offsets_mapping=True,
        truncation=False,
        verbose=False,
    )
    offsets = encoded["offset_mapping"]
    chunks: list[Chunk] = []
    start = 0
    while start < len(offsets):
        end = min(start + config.chunk_size, len(offsets))
        char_start = offsets[start][0]
        # A cut through a WordPiece can change tokenization of the returned substring.
        # Recount it, shrinking if needed, so chunk_size is an actual upper bound.
        while True:
            char_end = offsets[end - 1][1]
            chunk_text = text[char_start:char_end]
            token_count = len(
                tokenizer.encode(
                    chunk_text, add_special_tokens=False, truncation=False, verbose=False
                )
            )
            if token_count <= config.chunk_size:
                break
            end -= 1
            if end <= start:
                raise ValueError("chunk_size is too small for this tokenizer boundary")
        chunk_sources = tuple(
            SourceSpan(
                span.page_number,
                span.section,
                max(span.start_char, char_start) - char_start,
                min(span.end_char, char_end) - char_start,
            )
            for span in spans
            if span.start_char < char_end and span.end_char > char_start
        )
        identity = {
            "pipeline": PIPELINE_VERSION,
            "document": document.paper.document_id,
            "tokenizer": f"{MODEL_NAME}@{MODEL_REVISION}",
            "settings": config.indexing_settings,
            "token_start": start,
            "token_end": end,
            "text": chunk_text,
        }
        chunks.append(
            Chunk(
                stable_hash(identity),
                document.paper,
                chunk_text,
                token_count,
                start,
                end,
                char_start,
                char_end,
                chunk_sources,
            )
        )
        if end == len(offsets):
            break
        start = max(start + 1, end - config.overlap)
    return chunks
